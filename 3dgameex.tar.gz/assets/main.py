import asyncio, sys, pygame, math, random

async def main():

     pygame.init()
     screen = pygame.display.set_mode((1170,650),pygame.SCALED)
     run = True

     class Game():
          def __init__(self):
               self.CollidedZ = 0
               self.DecayTime = -2
               self.Active = False
               self.Cubes = []
               self.Level = 0
               self.TransitionTime = 0
     class Player():
          def __init__(self,x,y,z,zv,dir):
               self.X = x
               self.Y = y
               self.Z = z
               self.Zv = zv
               self.Dir = dir
               self.oldPx = 0
               self.oldPy = 0
     player = Player(0,0,0,0,0)

     Game = Game()
     player.X = 1
     player.Y = 1
     player.Z = 1
     xV = 0
     yV = 0
     renderingProcess = 1
     camX = 6
     camY = -3.3
     camZ = 6
     player.Dir = 1 # front right left back
     Game.Active = False
     Game.DecayTime = 0
     Game.TransitionTime = 2

     vY = screen.get_height()/2 - 500
     vX = screen.get_width()/2

     dY = vY
     dX = 2*vX + 400
     clock = pygame.time.Clock()
     running_in_browser = sys.platform == "emscripten"
     
     baseLength = 90
     Game.Cubes = []
     Game.CollidedZ = 0
     Game.Level = 1


     class Cube:
          def __init__(self,x,y,z,tile,color,length=90,property = False,decay = 0):
               self.decay = decay
               if Game.Level == 1 and self.decay == 0:
                    self.decay = x/3 + 0.5 + random.randint(100,200)/100
               elif Game.Level == 2 and self.decay == 0:
                    if z == 0:
                         self.decay = (((-1-x)**2 + (1-y)**2)**0.5)/10
                    elif x == 1 or x == 2:
                         if y == 1 or y == 2:
                              self.decay = random.randint(200,300)/100
                         else:
                              self.decay = random.randint(350,450)/100
                    elif x == 4 or x == 5:
                         if y == 1 or y == 2:
                              self.decay = random.randint(275,375)/100
                         else:
                              self.decay = random.randint(425,525)/100
                    elif x == 8 or x == 9:
                         self.decay = random.randint(525,625)/100
                    else:
                         self.decay = random.randint(700,800)/100
               elif Game.Level == 3 and self.decay == 0:
                    self.decay = (((-1-x)**2 + (1-y)**2)**0.5 + z**0.5)/3 + 1
                    if ((-4-x)**2 + (9-y)**2)**0.5 < 7 or ((16-x)**2 + (-2-y)**2)**0.5 < 7 and z == 0:
                         self.decay = random.randint(0,75)/100
               elif Game.Level == 4 and self.decay == 0:
                    self.decay = (((-1-x)**2 + (1-y)**2)**0.5)/3 + 1 + z/3
               
               elif Game.Level == 5 and self.decay == 0:
                    if (x in [3,4,5,6] or x in [9,10,11,12]) and not (x == 5 and y == 5) and not (x == 11 and y == 2):
                         self.decay = random.randint(0,50)/100
                    else:
                         self.decay = x/3 + 0.5 + random.randint(100,200)/100
               elif Game.Level == 6:
                    self.decay = 2 + (((-1-x)**2 + (1-2*y)**2)**0.5)/4 + z/5
                    if x in (9,10,11,12):
                         self.decay = random.randint(50,100)/100
               elif Game.Level == 7:
                    self.decay = (((6-x)**2 + (4-y)**2)**0.5)/3 + z*2

               else:
                    self.decay = 3600
               self.posX = x
               self.posY = y
               self.posZ = z - 1
               self.Rx = 0
               self.Ry = 0
               self.tile = tile
               self.color = color
               self.property = property
               self.zv = 0
               self.cL = 0
               self.m = 0
               self.m2 = 0
               self.m3 = 0
               self.m4 = 0
               self.m5 = 0
               self.solveY = 0
               self.camDist = 0
               self.length = length
               self.actualZ = self.posZ
               self.zAddend = random.randint(-20,-18) + 2*z
               self.multi = random.randint(90,95)/100
               self.dead = False
               self.render = False
               
          #render(border) border = outline thickness. 0 = filled/solid
          def renderSides(self,border):
               
               if self.tile == False:

                    if self.Rx + self.cL/2 >= vX:
                         if border == 0:
                              rColor = (self.color[0]+20, self.color[1]+20, self.color[2]+20)
                         else:
                                   rColor = (255,255,255)
                         
                         #right
                         # pygame.draw.polygon(screen,(255,255,255),((self.Rx+self.cL,self.Ry),
                         #                                         (self.Rx+self.cL,self.Ry-self.cL),
                         #                                         ((self.solveY+self.m1*(self.Rx+self.cL)-self.Ry)/self.m1,
                         #                                                                  self.m3*((self.solveY+self.m1*(self.Rx+self.cL)-self.Ry)/self.m1 - vX)+vY),
                         #                                              (((self.solveY+self.m1*(self.Rx+self.cL)-self.Ry)/self.m1,self.solveY))),border)

                         
                         #left
                         pygame.draw.polygon(screen,rColor,(
                              (self.Rx,self.Ry),
                              (self.Rx,self.Ry-self.cL),
                              ((self.solveY+self.m2*(self.Rx)-self.Ry)/self.m2,self.m4*(((self.solveY+self.m2*(self.Rx)-self.Ry)/self.m2)  - vX) + vY),
                              ((self.solveY+self.m2*(self.Rx)-self.Ry)/self.m2,self.solveY)
                         ),border)

                    elif self.Rx + self.cL/2 < vX:
                         if border == 0:
                              rColor = (self.color[0]+20, self.color[1]+20, self.color[2]+20)
                         else:
                                   rColor = (255,255,255)
                         #right

                         pygame.draw.polygon(screen,rColor,(
                              (self.Rx+self.cL,self.Ry),
                              (self.Rx+self.cL,self.Ry-self.cL),
                              ((self.solveY+self.m2*(self.Rx+self.cL)-self.Ry)/self.m2, self.m3*(((self.solveY+self.m2*(self.Rx+self.cL)-self.Ry)/self.m2) - vX) + vY),
                              ((self.solveY+self.m2*(self.Rx+self.cL)-self.Ry)/self.m2,self.solveY)
                         ),border)


                         #left
                         # pygame.draw.polygon(screen,(255,255,255),(
                         #      (self.Rx,self.Ry),
                         #      (self.Rx,self.Ry-self.cL),
                         #      ((self.solveY+self.m1*(self.Rx)-self.Ry)/self.m1,self.m4*(((self.solveY+self.m1*(self.Rx)-self.Ry)/self.m1)-vX)+vY),
                         #      ((self.solveY+self.m1*(self.Rx)-self.Ry)/self.m1,self.solveY)
                         # ),border)



          def renderTop(self,border):
               if border == 0:
                         rColor = (self.color[0]+40, self.color[1]+40, self.color[2]+40)
               else:
                         rColor = (255,255,255)
               if self.Rx + self.cL/2 >= vX:
                    if self.Ry + self.cL/2 >= vY:
                         #top
                         pygame.draw.polygon(screen,rColor,(
                              (self.Rx+self.cL,self.Ry-self.cL),
                              ((self.solveY+self.m1*(self.Rx+self.cL)-self.Ry)/self.m1, self.m3*((self.solveY+self.m1*(self.Rx+self.cL)-self.Ry)/self.m1 - vX)+vY),
                              ((self.solveY+self.m2*(self.Rx)-self.Ry)/self.m2,self.m4*(((self.solveY+self.m2*(self.Rx)-self.Ry)/self.m2)  - vX) + vY),
                              (self.Rx,self.Ry-self.cL),
                         ),border)
                    else:
                         self.renderBottom(0)
                         
               elif self.Rx + self.cL/2 < vX:
                    if self.Ry + self.cL/2 >= vY:
                    #top
                         pygame.draw.polygon(screen,rColor,(
                              (self.Rx+self.cL,self.Ry-self.cL),
                              ((self.solveY+self.m2*(self.Rx+self.cL)-self.Ry)/self.m2, self.m3*(((self.solveY+self.m2*(self.Rx+self.cL)-self.Ry)/self.m2) - vX) + vY),
                              ((self.solveY+self.m1*(self.Rx)-self.Ry)/self.m1,self.m4*(((self.solveY+self.m1*(self.Rx)-self.Ry)/self.m1)-vX)+vY),
                              (self.Rx,self.Ry-self.cL)
                         ),border)
                    else:
                         self.renderBottom(0)

          def renderBottom(self,border):
               if border == 0:
                         rColor = (self.color[0]-20, self.color[1]-20, self.color[2]-20)
               else:
                         rColor = (255,255,255)
               if self.tile == False:

                    if self.Rx + self.cL/2 >= vX:
                         pygame.draw.polygon(screen,(rColor),(
                         (self.Rx,self.Ry),
                         (self.Rx+self.cL,self.Ry),
                         ((self.solveY+self.m1*(self.Rx+self.cL)-self.Ry)/self.m1,self.solveY),
                         ((self.solveY+self.m2*(self.Rx)-self.Ry)/self.m2,self.solveY)
                         ),border)
                    elif self.Rx + self.cL/2 < vX:
                         pygame.draw.polygon(screen,(rColor),(
                         (self.Rx,self.Ry),
                         (self.Rx+self.cL,self.Ry),
                         ((self.solveY+self.m2*(self.Rx+self.cL)-self.Ry)/self.m2,self.solveY),
                         ((self.solveY+self.m1*(self.Rx)-self.Ry)/self.m1,self.solveY)
                         ),border)






          def renderFront(self,border):
               if self.tile == False:
                    if border == 0:
                              rColor = (self.color[0], self.color[1], self.color[2])
                    else:
                              rColor = (255,255,255)
                    if self.Rx + self.cL/2 >= vX:
                         #front
                         pygame.draw.polygon(screen,rColor,(
                              (self.Rx,self.Ry),
                              (self.Rx+self.cL,self.Ry),
                              (self.Rx+self.cL,self.Ry-self.cL),
                              (self.Rx,self.Ry-self.cL)
                         ),border)
                    elif self.Rx + self.cL/2 < vX:
                         #front
                         pygame.draw.polygon(screen,rColor,(
                              (self.Rx,self.Ry),
                              (self.Rx+self.cL,self.Ry),
                              (self.Rx+self.cL,self.Ry-self.cL),
                              (self.Rx,self.Ry-self.cL)
                         ),border)








          def variables(self):
               lX = self.posX * (1170/13)
               mL = (vY - 650)/(vX - lX) # slope to vp
               renderFloorY = 650 - 120*((self.posY)**(1/2)) # starts at bottom of screen, each consecutive row is moved up by a smaller amount due to sqrt
               self.cL = self.length-self.length*((650-renderFloorY)/825) #cube length approaches zero as posY approaches vanishing point vY
               cL2 = baseLength-baseLength*((650-renderFloorY)/825) 
               self.Rx = (renderFloorY-vY)/mL + vX # intersection of lines i think
               self.Ry = renderFloorY-self.posZ*cL2 + 50 #posY is where it renders on the floor grid, then it just moves it up by cube length * cube z times
               if self.Rx + self.cL/2 >= vX:
                    if vX - self.Rx - self.cL == 0:
                         self.m1 = 100000000
                    else:
                         self.m1 = (vY-self.Ry)/(vX-self.Rx-self.cL)
                    
                    self.m5 = (dY - self.Ry)/(dX - self.Rx)
                    self.solveY = self.m1*( ((self.m1*self.Rx - self.m5*self.Rx + self.m1*self.cL)/(self.m1 - self.m5)) - self.Rx - self.cL) + self.Ry
                    if vX - self.Rx == 0:
                         self.m2 = -100000000
                    else:
                         self.m2 = (vY-self.Ry)/(vX-self.Rx)

                    self.m3 = (vY - (self.Ry-self.cL))/(vX - (self.Rx+self.cL))
                    self.m4 = (vY - (self.Ry-self.cL))/(vX - self.Rx)

               elif self.Rx + self.cL/2 < vX:
                    if vX - self.Rx == 0:
                         self.m1 = -10000000
                    else:
                         self.m1 = (vY-self.Ry)/(vX-self.Rx)
                    
                    m6 = (vY-self.Ry)/(vX-self.Rx-self.cL)
                    self.m5 = (dY - self.Ry)/(dX - self.Rx)
                    self.solveY = m6*( ((m6*self.Rx - self.m5*self.Rx + m6*self.cL)/(m6 - self.m5)) - self.Rx - self.cL) + self.Ry
                    if vX-(self.Rx+self.cL) == 0:
                         self.m2 = 100000000
                    else:
                         self.m2 = (vY-self.Ry)/(vX-(self.Rx+self.cL))
                    self.m3 = (vY - (self.Ry - self.cL))/(vX - (self.Rx + self.cL))
                    self.m4 = (vY - (self.Ry - self.cL))/(vX - self.Rx)

          #special colors




          def checkColl(self):
               if abs((self.posX)-(player.X-0.1)) < 1.1 and abs((self.posY)-(player.Y)) < 0.99 and abs((self.posZ)-(player.Z)) < 0.99:
                    return(True)
               



     def collide():
          Game.CollidedZ
          Game.Cubes
          for c in Game.Cubes:
               if c.checkColl():
                    Game.CollidedZ = c.posZ + 1
                    if c.color == goalColor:
                         Game.Level += 1
                         if Game.Level == 8:
                              Game.Level = 1
                         resetLevel()

                         

                    return(True)
     def column(xy,height):
          hPos = 0
          for i in range(height):
               hPos += 1
               Game.Cubes.append(Cube(xy[0],xy[1],hPos,False,platformColor))

     def box(xyz,l,w,h): # x = length, y = width, z = height etc etc 
          for x in range(l):
               for y in range(w):
                    column((xyz[0]+x,xyz[1]+y),h)




     player.Zv = 0
     walkingAnim = 0

     platformColor = (215,215,215)

     baseColor = 179, 71, 77

     goalColor = (215, 117, 57)
     def fullFloor():
          CubeY = 0
          CubeZ = 0
          CubeY = 1
          for i in range(7):
               CubeZ = 0

               for i in range(1):
                    CubeX = -1
                    for i in range(15):
                         if (CubeX+CubeY)%2 == 0:
                              Game.Cubes.append(Cube(CubeX,CubeY,CubeZ,False,baseColor,90))

                         else:
                              Game.Cubes.append(Cube(CubeX,CubeY,CubeZ,False,(baseColor[0]-20,baseColor[1]-20,baseColor[2]-20),90))

                         CubeX += 1
                    CubeZ += 1
               CubeY += 1
     def Level():
          if Game.Level == 1:
               box ((12,2,0),2,3,6)
               column((2,3),1)
               column((4,3),2)
               column((6,3),3)
               column((8,3),4)
               column((10,3),5)

               Game.Cubes.append(Cube(13,3,7,False,goalColor,90,False,3600))
          elif Game.Level == 2:
               box((1,1,1),2,2,1)
               box((4,1,1),2,2,2)
               box((1,4,1),2,2,3)
               box((4,4,1),2,2,4)
               box((8,1,1),2,2,4)
               box((11,3,1),3,3,5)
               Game.Cubes.append(Cube(13,4,6,False,goalColor,90,False,3600))
          elif Game.Level == 3:
               box((11,4,1),3,3,5)
               column((1,2),1)
               column((4,2),2)
               column((6,3),3)
               column((8,5),4)
               Game.Cubes.append(Cube(13,6,6,False,goalColor,90,False,3600))
          elif Game.Level == 4:
               box((2,5,0),3,3,3)
               column((2,3),1)
               column((0,5),2)
               box((7,2,1),2,2,4)
               box((11,5,1),2,2,5)

               Game.Cubes.append(Cube(12,6,6,False,goalColor,90,False,3600))
          elif Game.Level == 5:
               column((1,3),1)
               column((2,5),2)
               column((5,5),3)
               column((8,3),2)
               column((11,2),2)
               Game.Cubes.append(Cube(13,1,1,False,goalColor,90,False,3600))
          elif Game.Level == 6:
               box((1,2,1),1,1,1)
               column((0,5),2)
               column((2,6),3)
               column((4,4),4)
               box((7,3),2,2,4)
               for c in Game.Cubes:
                    if c.posX in (7,8) and c.posY in (3,4) and c.posZ == 3:
                         c.property = "speed"
               Game.Cubes.append(Cube(13,4,3,False,goalColor,90,False,3600))
               column((13,4),2)
          elif Game.Level == 7:
               column((0,2),1)
               column((3,3),2)
               column((5,2),3)
               column((9,4),4)
               for c in Game.Cubes:
                    if c.posZ != -1 and c.dead == False:
                         c.property = "speed"
               column((13,1),2)
               Game.Cubes.append(Cube(13,1,3,False,goalColor,90,False,3600))
          elif Game.Level == 8:
               for c in Game.Cubes:
                    c.decay = (c.posX % c.posY)/7  + random.randint(0,25)/100
               box((1,1,1),1,5,1)
               box((1,6,1),7,1,1)
               box((7,3),1,3,1)
               box((8,3),3,1,1)
               box((11,1),1,3,1)
               Game.Cubes.append(Cube(12,1,1,False,platformColor))
               Game.Cubes.append(Cube(13,1,1,False,goalColor,90,False,3600))
               for c in Game.Cubes:
                    if c.dead == False and c.color == platformColor:
                         c.property = "speed"
                         c.decay = c.posX/6 + 1 + random.randint(0,30)/100

     def resetLevel():
          for c in Game.Cubes:
               c.dead = True
               c.decay = 2 - random.randint(1,30)/60
          Game.TransitionTime = 2
          Game.DecayTime = -0.1
          fullFloor()
          Level()

          for c in Game.Cubes:
               c.variables()
               c.posZ = c.actualZ + c.zAddend


     stars = []
     # glow = pygame.image.load("glow3.png").convert_alpha()
     # glow.set_alpha(30)
     # glow1 = pygame.transform.scale(glow,(300,300))
     # glow2 = pygame.transform.scale(glow,(350,350))
     # glow3 = pygame.transform.scale(glow,(400,400))
     # glow4 = pygame.transform.scale(glow,(450,450))
     # glow5 = pygame.transform.scale(glow,(500,500))

     fullFloor()
     Level()

     #stars
     class Star:
          def __init__(self,x, y, size):
               self.x = x
               self.y = y
               self.xv = 0.5 * size
               self.yv = 0.5 * size
               self.size = size

     for i in range(100):
          stars.append(Star(random.randint(0,screen.get_width()),random.randint(0,screen.get_height()),random.choices((1,2,3,4,5),(0.3,0.3,0.2,0.15,0.05))[0]))
     screen.fill((10,10,10))

     # make components

     playerColor = (52, 115, 199)
     playerCube = Cube(0,0,0,False, playerColor,75)
     playerHead = Cube(0,0,0,False, playerColor,85)
     playerFace = Cube(0,0,0,False,(0,0,0),75)
     playerLEye = Cube(0,0,0,False,(235,235,235),10)
     playerREye = Cube(0,0,0,False,(235,235,235),10)


     playerLFoot = Cube(0,0,0,False,playerColor,30)
     playerRFoot = Cube(0,0,0,False,playerColor,30)


     speed = 0.012
     while run:

          pygame.display.set_caption("Level " + str(Game.Level))
          keys = pygame.key.get_pressed()

               
          if Game.Active:
               Game.DecayTime += (1/60)
          if Game.TransitionTime > 0:
               Game.TransitionTime -= 1/60
               Game.DecayTime = -0.1
               Game.Active = False
               player.Zv = 0
               player.X = 1
               player.Y = 1
               player.Z = 1
               player.oldPx = player.X
               player.oldPy = player.Y
               player.Dir = 1
          for c in Game.Cubes:
               if c.dead == False:
                    if Game.TransitionTime < 0:
                         if Game.DecayTime > c.decay:
                              c.zv -= 0.02
               else:
                    if Game.TransitionTime < c.decay:
                         c.zv -= 0.02
               c.posZ += c.zv
               if c.posZ < -21:
                    Game.Cubes.remove(c)
               if c.property == "speed":
                    c.color = (214, 182, 24)
               elif c.property == "ice":
                    c.color = (151, 204, 203)
               elif c.property == "jump":
                    c.color = (50,200,100)
          for c in Game.Cubes:
               if c.zAddend < -0.05:
                    c.zAddend = c.zAddend * c.multi
                    c.posZ = c.actualZ + c.zAddend
                    c.render = True
               

          screen.fill((30,0,30))
          for event in pygame.event.get():
               if event.type == pygame.QUIT:
                    run = False
               if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP:
                         camY += 0.1
                    if event.key == pygame.K_DOWN:
                         camY -= 0.1   
          for s in stars:
               size = 200+50*s.size

               # if s.size == 1:
               #      screen.blit(glow1,(s.x-size/2,s.y-size/2))
               # elif s.size == 2:
               #      screen.blit(glow2,(s.x-size/2,s.y-size/2))
               # elif s.size == 3:
               #      screen.blit(glow3,(s.x-size/2,s.y-size/2))
               # elif s.size == 4:
               #      screen.blit(glow4,(s.x-size/2,s.y-size/2))
               # elif s.size == 5:
               #      screen.blit(glow5,(s.x-size/2,s.y-size/2))
                    
               
               s.x += s.xv
               s.y += s.yv
               if s.x > 1300:
                    s.x = -100
               if s.x < -100:
                    s.x = 1300
               if s.y > 800:
                    s.y = -100
               if s.y < -100:
                    s.y = 800
          for s in stars:
               #pygame.draw.circle(screen,(255,255,255),(s.x,s.y),s.size)
               pygame.draw.polygon(screen,(255,255,255),((s.x-s.size,s.y),(s.x,s.y+s.size),(s.x + s.size,s.y),(s.x,s.y-s.size)))
               
          # screen.fill((100,100,100))
     # rendering cubes

     # DEPTH IS Y AXIS
     # Z AXIS IS UP/DOWN

                         
          for i in Game.Cubes:
               i.variables()

                    

          # collisions

          player.Zv -= 0.02
          player.Z += player.Zv


          effects = []
          
          for c in Game.Cubes:
               if abs((c.posX)-(player.X-0.1)) < 1.1 and abs((c.posY)-(player.Y)) < 1:
                    effects.append(c.property)

          if collide():
               player.Z = Game.CollidedZ
               player.Zv = 0
               if keys[pygame.K_SPACE]:
                    if "jump" in effects:
                         player.Zv = 0.4
                    else:
                         player.Zv = 0.29

          print(effects)
          maxSpeed = .0857
          print(xV)
          if "ice" in effects:
               yV = yV * 0.98
               xV = xV * 0.98
               if xV > maxSpeed:
                    xV = maxSpeed
               if xV < -maxSpeed:
                    xV = -maxSpeed
               if yV > maxSpeed:
                    yV = maxSpeed
               if yV < -maxSpeed:
                    yV = -maxSpeed
          else:
               yV = yV * 0.86
               xV = xV * 0.86


          


          player.oldPx = playerCube.posX
          player.oldPy = playerCube.posY
          player.X += xV

          if collide():
               player.X = player.oldPx
               xV = 0

          player.Y += yV

          if collide():
               player.Y = player.oldPy
               yV = 0
          if "speed" in effects:
               speed = 0.03
          else:
               speed = 0.012
          if keys[pygame.K_w] or keys[pygame.K_UP]:
               yV += speed
               player.Dir = 4
               Game.Active = True
          if keys[pygame.K_s] or keys[pygame.K_DOWN]:
               yV -= speed
               player.Dir = 1
               Game.Active = True
          if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
               xV += speed
               player.Dir = 2
               Game.Active = True
          if keys[pygame.K_a] or keys[pygame.K_LEFT]:
               xV -= speed
               player.Dir = 3
               Game.Active = True
          if keys[pygame.K_a] or keys[pygame.K_LEFT] or keys[pygame.K_s] or keys[pygame.K_DOWN] or keys[pygame.K_d] or keys[pygame.K_RIGHT] or keys[pygame.K_w] or keys[pygame.K_UP]:
               walkingAnim += 0.1


          # front wall
          if player.Y <= 1:
               player.Y = 1

          # player components 
          playerCube.posX = player.X
          playerCube.posY = player.Y
          playerCube.posZ = player.Z+0.2
          playerCube.variables()

          playerHead.posX = player.X-0.05
          playerHead.posY = player.Y
          playerHead.posZ = player.Z+0.6


          playerLFoot.posX = player.X + 0.1
          playerLFoot.posY = player.Y + 0.2
          playerLFoot.posZ = player.Z
          
          if player.Dir == 1:
               playerLFoot.posX = player.X
               playerLFoot.posY = player.Y + 0.2 + 0.3*math.sin(walkingAnim)
               playerLFoot.posZ = player.Z


               playerRFoot.posX = player.X + 0.5
               playerRFoot.posY = player.Y + 0.2 +  0.3*math.sin(walkingAnim + 3.14159)
               playerRFoot.posZ = player.Z
          elif player.Dir == 2:
               playerLFoot.posX = player.X + 0.25 + 0.3*math.sin(walkingAnim + 3.14159)
               playerLFoot.posY = player.Y + 0.2
               playerLFoot.posZ = player.Z


               playerRFoot.posX = player.X + 0.25 + 0.3*math.sin(walkingAnim)
               playerRFoot.posY = player.Y + 0.5
               playerRFoot.posZ = player.Z
          elif player.Dir == 3:
               playerLFoot.posX = player.X + 0.25 + 0.3*math.sin(walkingAnim)
               playerLFoot.posY = player.Y + 0.2
               playerLFoot.posZ = player.Z


               playerRFoot.posX = player.X + 0.25 + 0.3*math.sin(walkingAnim+3.14159)
               playerRFoot.posY = player.Y + 0.5
               playerRFoot.posZ = player.Z


          elif player.Dir == 4:
               playerLFoot.posX = player.X
               playerLFoot.posY = player.Y + 0.2 +  0.3*math.sin(walkingAnim+ 3.14159)
               playerLFoot.posZ = player.Z
               
               playerRFoot.posX = player.X + 0.5
               playerRFoot.posY = player.Y + 0.2 + 0.3*math.sin(walkingAnim)
               playerRFoot.posZ = player.Z
          playerFace.posX = player.X
          playerFace.posY = player.Y
          playerFace.posZ = player.Z + 0.65

          if player.Dir == 1:
               playerLEye.posX = player.X+0.1
               playerLEye.posY = player.Y-0.01
               playerLEye.posZ = player.Z+0.9

               playerREye.posX = player.X+0.6
               playerREye.posY = player.Y-0.01
               playerREye.posZ = player.Z+0.9
          elif player.Dir == 2:
               playerLEye.posX = player.X+0.8
               playerLEye.posY = player.Y+0.7
               playerLEye.posZ = player.Z+0.9

               playerREye.posX = player.X+0.8
               playerREye.posY = player.Y+0.2
               playerREye.posZ = player.Z+0.9
          elif player.Dir == 3:
               playerLEye.posX = player.X-0.05
               playerLEye.posY = player.Y+0.7
               playerLEye.posZ = player.Z+0.9

               playerREye.posX = player.X-0.05
               playerREye.posY = player.Y+0.2
               playerREye.posZ = player.Z+0.9

          playerHead.variables()
          playerLFoot.variables()
          playerRFoot.variables()
          playerFace.variables()
          playerLEye.variables()
          playerREye.variables()

          distances = []
          for c in Game.Cubes:
               c.camDist = (math.sqrt((camX - c.posX)**2 + (camY - c.posY)**2 + (camZ - c.posZ)**2))
               if not c.camDist in distances:
                    distances.append(c.camDist)
          playerCube.camDist = (math.sqrt((camX - playerCube.posX)**2 + (camY - playerCube.posY)**2 + (camZ - playerCube.posZ)**2)) - 0.4

          distances.append(playerCube.camDist)
          distances.sort()
          distances.reverse()
          
          # border
          for d in distances:
               for c in Game.Cubes:
                    if c.camDist == d:
                         if c.render:#c.zv == 0 and c.zAddend > -0.05:
                              c.renderSides(5)
                              c.renderTop(5)
                              c.renderFront(5)




          # calc distances to camera
          distances = []
          for c in Game.Cubes:
               c.camDist = (math.sqrt((camX - c.posX)**2 + (camY - c.posY)**2 + (camZ - c.posZ)**2))
               if not c.camDist in distances:
                    distances.append(c.camDist)
          playerCube.camDist = (math.sqrt((camX - playerCube.posX)**2 + (camY - playerCube.posY)**2 + (camZ - playerCube.posZ)**2)) - 0.4

          distances.append(playerCube.camDist)
          distances.sort()
          distances.reverse()

          for d in distances:
               # render level cubes
               for c in Game.Cubes:
                    if c.camDist == d and c.render == True:
                         c.renderSides(0)
                         c.renderTop(0)
                         c.renderFront(0)
               # render player
               if playerCube.camDist == d:
                    if playerCube.Ry - playerCube.cL/2 < vY:
                         playerCube.renderBottom(0)
                    if playerHead.Ry - playerHead.cL/2 < vY:
                         playerHead.renderBottom(0)
                         
                    playerLFoot.renderSides(0)
                    playerLFoot.renderFront(0)
                    if playerLFoot.Ry - playerLFoot.cL/2 > vY:
                         playerLFoot.renderTop(0)
                    else:
                         playerLFoot.renderBottom(0)

                    playerRFoot.renderSides(0)
                    playerRFoot.renderFront(0)
                    if playerRFoot.Ry - playerRFoot.cL/2 > vY:
                         playerRFoot.renderTop(0)
                    else:
                         playerRFoot.renderBottom(0)
                    
                    playerCube.renderSides(0)
                    playerCube.renderFront(0)
                    if playerCube.Ry - playerCube.cL/2 > vY:
                         playerCube.renderTop(0)

                    if player.Dir == 1:
                         playerHead.renderSides(0)
                         playerHead.renderFront(0)
                         playerFace.renderFront(0)
                         playerLEye.renderFront(0)
                         playerREye.renderFront(0)
                    elif player.Dir == 2 or player.Dir == 3:
                         playerHead.renderSides(0)
                         if player.Dir == 2:
                              if playerFace.Rx+playerFace.cL/2 < vX:
                                   playerFace.renderSides(0)
                         else:
                              if playerFace.Rx+playerFace.cL/2 > vX:
                                   playerFace.renderSides(0)
                         playerLEye.renderSides(0)
                         playerREye.renderSides(0)
                         playerHead.renderFront(0)
                    elif player.Dir == 4:
                         playerHead.renderSides(0)
                         playerHead.renderFront(0)
                    if playerHead.Ry - playerHead.cL/2 > vY:
                         playerHead.renderTop(0)
                    # antenna
                    if player.Dir == 1:
                         if playerHead.Rx + playerHead.cL/2 >= vX:
                              pygame.draw.line(screen,(100,100,100),
                                             ((playerHead.solveY+playerHead.m2*(playerHead.Rx)-playerHead.Ry)/playerHead.m2 + 0.2*((playerHead.Rx+playerHead.cL)-(playerHead.solveY+playerHead.m2*(playerHead.Rx)-playerHead.Ry)/playerHead.m2),
                                             playerHead.Ry-playerHead.cL+ 0.8*((playerHead.m4*(((playerHead.solveY+playerHead.m2*(playerHead.Rx)-playerHead.Ry)/playerHead.m2)  - vX) + vY)-(playerHead.Ry-playerHead.cL))
                                             ),((playerHead.solveY+playerHead.m2*(playerHead.Rx)-playerHead.Ry)/playerHead.m2 + 0.2*((playerHead.Rx+playerHead.cL)-(playerHead.solveY+playerHead.m2*(playerHead.Rx)-playerHead.Ry)/playerHead.m2),
                                             playerHead.Ry-playerHead.cL+ 0.8*((playerHead.m4*(((playerHead.solveY+playerHead.m2*(playerHead.Rx)-playerHead.Ry)/playerHead.m2)  - vX) + vY)-(playerHead.Ry-playerHead.cL))- 40*(playerHead.cL/playerHead.length)
                                             ),round(9*(playerHead.cL/playerHead.length)))
                         else:
                              pygame.draw.line(screen,(100,100,100),
                                             ((playerHead.solveY+playerHead.m1*(playerHead.Rx)-playerHead.Ry)/playerHead.m1 + 0.2*((playerHead.Rx+playerHead.cL)-(playerHead.solveY+playerHead.m1*(playerHead.Rx)-playerHead.Ry)/playerHead.m1),
                                             playerHead.Ry-playerHead.cL+ 0.8*((playerHead.m4*(((playerHead.solveY+playerHead.m1*(playerHead.Rx)-playerHead.Ry)/playerHead.m1)-vX)+vY)-(playerHead.Ry-playerHead.cL))
                                             ),
                                             ((playerHead.solveY+playerHead.m1*(playerHead.Rx)-playerHead.Ry)/playerHead.m1 + 0.2*((playerHead.Rx+playerHead.cL)-(playerHead.solveY+playerHead.m1*(playerHead.Rx)-playerHead.Ry)/playerHead.m1),
                                             playerHead.Ry-playerHead.cL+ 0.8*((playerHead.m4*(((playerHead.solveY+playerHead.m1*(playerHead.Rx)-playerHead.Ry)/playerHead.m1)-vX)+vY)-(playerHead.Ry-playerHead.cL))- 40*(playerHead.cL/playerHead.length)
                                             ),round(9*(playerHead.cL/playerHead.length)))   
                    elif player.Dir == 2:
                         if playerHead.Rx + playerHead.cL/2 >= vX:
                              pygame.draw.line(screen,(100,100,100),
                                             (playerHead.Rx + 0.15*((playerHead.Rx+playerHead.cL)-(playerHead.Rx)),
                                             playerHead.Ry-playerHead.cL+ 0.2*((playerHead.m4*(((playerHead.solveY+playerHead.m2*(playerHead.Rx)-playerHead.Ry)/playerHead.m2)  - vX) + vY)-(playerHead.Ry-playerHead.cL))
                                             ),((playerHead.Rx + 0.15*((playerHead.Rx+playerHead.cL)-(playerHead.Rx))),
                                             playerHead.Ry-playerHead.cL+ 0.2*((playerHead.m4*(((playerHead.solveY+playerHead.m2*(playerHead.Rx)-playerHead.Ry)/playerHead.m2)  - vX) + vY)-(playerHead.Ry-playerHead.cL))- 40*(playerHead.cL/playerHead.length)
                                             ),round(9*(playerHead.cL/playerHead.length)))
                         else:
                              pygame.draw.line(screen,(100,100,100),
                                             (playerHead.Rx + 0.15*((playerHead.Rx+playerHead.cL)-(playerHead.Rx)),
                                             playerHead.Ry-playerHead.cL+ 0.2*((playerHead.m4*(((playerHead.solveY+playerHead.m1*(playerHead.Rx)-playerHead.Ry)/playerHead.m1)-vX)+vY)-(playerHead.Ry-playerHead.cL))
                                             ),
                                             (playerHead.Rx + 0.15*((playerHead.Rx+playerHead.cL)-(playerHead.Rx)),
                                             playerHead.Ry-playerHead.cL+ 0.2*((playerHead.m4*(((playerHead.solveY+playerHead.m1*(playerHead.Rx)-playerHead.Ry)/playerHead.m1)-vX)+vY)-(playerHead.Ry-playerHead.cL))- 40*(playerHead.cL/playerHead.length)
                                             ),round(9*(playerHead.cL/playerHead.length)))   

                    elif player.Dir == 3:
                         if playerHead.Rx + playerHead.cL/2 >= vX:
                              pygame.draw.line(screen,(100,100,100),
                                             (playerHead.Rx + 0.9*((playerHead.Rx+playerHead.cL)-(playerHead.Rx)),
                                             playerHead.Ry-playerHead.cL+ 0.2*((playerHead.m4*(((playerHead.solveY+playerHead.m2*(playerHead.Rx)-playerHead.Ry)/playerHead.m2)  - vX) + vY)-(playerHead.Ry-playerHead.cL))
                                             ),((playerHead.Rx + 0.9*((playerHead.Rx+playerHead.cL)-(playerHead.Rx))),
                                             playerHead.Ry-playerHead.cL+ 0.2*((playerHead.m4*(((playerHead.solveY+playerHead.m2*(playerHead.Rx)-playerHead.Ry)/playerHead.m2)  - vX) + vY)-(playerHead.Ry-playerHead.cL))- 40*(playerHead.cL/playerHead.length)
                                             ),round(9*(playerHead.cL/playerHead.length)))
                         else:
                              pygame.draw.line(screen,(100,100,100),
                                             (playerHead.Rx + 0.9*((playerHead.Rx+playerHead.cL)-(playerHead.Rx)),
                                             playerHead.Ry-playerHead.cL+ 0.2*((playerHead.m4*(((playerHead.solveY+playerHead.m1*(playerHead.Rx)-playerHead.Ry)/playerHead.m1)-vX)+vY)-(playerHead.Ry-playerHead.cL))
                                             ),
                                             (playerHead.Rx + 0.9*((playerHead.Rx+playerHead.cL)-(playerHead.Rx)),
                                             playerHead.Ry-playerHead.cL+ 0.2*((playerHead.m4*(((playerHead.solveY+playerHead.m1*(playerHead.Rx)-playerHead.Ry)/playerHead.m1)-vX)+vY)-(playerHead.Ry-playerHead.cL))- 40*(playerHead.cL/playerHead.length)
                                             ),round(9*(playerHead.cL/playerHead.length)))   
                              
                    if player.Dir == 4:
                         if playerHead.Rx + playerHead.cL/2 >= vX:
                              pygame.draw.line(screen,(100,100,100),
                                             ((playerHead.solveY+playerHead.m2*(playerHead.Rx)-playerHead.Ry)/playerHead.m2 + 0.8*((playerHead.Rx+playerHead.cL)-(playerHead.solveY+playerHead.m2*(playerHead.Rx)-playerHead.Ry)/playerHead.m2),
                                             playerHead.Ry-playerHead.cL+ 0.2*((playerHead.m4*(((playerHead.solveY+playerHead.m2*(playerHead.Rx)-playerHead.Ry)/playerHead.m2)  - vX) + vY)-(playerHead.Ry-playerHead.cL))
                                             ),((playerHead.solveY+playerHead.m2*(playerHead.Rx)-playerHead.Ry)/playerHead.m2 + 0.8*((playerHead.Rx+playerHead.cL)-(playerHead.solveY+playerHead.m2*(playerHead.Rx)-playerHead.Ry)/playerHead.m2),
                                             playerHead.Ry-playerHead.cL+ 0.2*((playerHead.m4*(((playerHead.solveY+playerHead.m2*(playerHead.Rx)-playerHead.Ry)/playerHead.m2)  - vX) + vY)-(playerHead.Ry-playerHead.cL))- 40*(playerHead.cL/playerHead.length)
                                             ),round(9*(playerHead.cL/playerHead.length)))
                         else:
                              pygame.draw.line(screen,(100,100,100),
                                             ((playerHead.solveY+playerHead.m1*(playerHead.Rx)-playerHead.Ry)/playerHead.m1 + 0.8*((playerHead.Rx+playerHead.cL)-(playerHead.solveY+playerHead.m1*(playerHead.Rx)-playerHead.Ry)/playerHead.m1),
                                             playerHead.Ry-playerHead.cL+ 0.2*((playerHead.m4*(((playerHead.solveY+playerHead.m1*(playerHead.Rx)-playerHead.Ry)/playerHead.m1)-vX)+vY)-(playerHead.Ry-playerHead.cL))
                                             ),
                                             ((playerHead.solveY+playerHead.m1*(playerHead.Rx)-playerHead.Ry)/playerHead.m1 + 0.8*((playerHead.Rx+playerHead.cL)-(playerHead.solveY+playerHead.m1*(playerHead.Rx)-playerHead.Ry)/playerHead.m1),
                                             playerHead.Ry-playerHead.cL+ 0.2*((playerHead.m4*(((playerHead.solveY+playerHead.m1*(playerHead.Rx)-playerHead.Ry)/playerHead.m1)-vX)+vY)-(playerHead.Ry-playerHead.cL))- 40*(playerHead.cL/playerHead.length)
                                             ),round(9*(playerHead.cL/playerHead.length)))   
          if Game.DecayTime < 0:
               player.Zv = 0
               player.X = 1
               player.Y = 1
               player.Z = 1
               player.Dir = 1
               xV = 0
               yV = 0
          if player.Z < -100:
               resetLevel()
          
          pygame.display.flip()
          if running_in_browser:
               # Browser: non-blocking
               await asyncio.sleep(0)
               clock.tick(60)

          else:
               # Desktop: normal FPS
               clock.tick(60)
asyncio.run(main())